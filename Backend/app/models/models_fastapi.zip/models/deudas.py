from sqlalchemy import Column, Integer, Text, DECIMAL, Enum, TIMESTAMP, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class Deuda(Base):
    __tablename__ = "deudas"

    id_deuda = Column(Integer, primary_key=True, autoincrement=True)
    id_usuario = Column(Integer, ForeignKey("usuarios.id_usuario"))
    fecha = Column(TIMESTAMP)
    total = Column(DECIMAL(12,2), nullable=False)
    estado = Column(Enum("pendiente","pagada","parcial"), default="pendiente")
    observaciones = Column(Text)

    usuario = relationship("Usuario")
